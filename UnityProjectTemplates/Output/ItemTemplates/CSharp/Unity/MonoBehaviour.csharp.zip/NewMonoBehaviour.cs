﻿using UnityEngine;
using System.Collections;

namespace $rootnamespace$
{
    public class $safeitemname$ : MonoBehaviour
    {
        private void Start()
        {

        }

        private void Update()
        {

        }
    }
}
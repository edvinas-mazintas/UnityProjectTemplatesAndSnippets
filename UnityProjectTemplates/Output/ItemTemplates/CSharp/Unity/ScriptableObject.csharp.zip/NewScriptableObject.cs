﻿using UnityEngine;

namespace $rootnamespace$
{
    [CreateAssetMenu(fileName = "$safeitemname$", menuName = "$safeitemname$", order = 0)]
    public class $safeitemname$ : ScriptableObject
    {
        
    }
}
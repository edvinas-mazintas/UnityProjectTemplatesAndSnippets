﻿using Unity.Entities;

namespace $rootnamespace$
{
    [GenerateAuthoringComponent]
    public struct $safeitemname$ : IComponentData
    {
        
    }
}
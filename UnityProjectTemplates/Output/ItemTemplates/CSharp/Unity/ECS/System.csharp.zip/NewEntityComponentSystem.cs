﻿using Unity.Entities;
using Unity.Jobs;

namespace $rootnamespace$
{
    [UpdateInGroup(typeof(SimulationSystemGroup))]
    public class $safeitemname$ : SystemBase
    {
        protected override void OnStartRunning()
        {
            
        }

        protected override void OnUpdate()
        {
            
        }
    }
}